package web;

import java.io.*;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet("/StudentServlet")
public class StudentServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private static final String DB_URL = "jdbc:mysql://localhost:3306/yourdb";
    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = "root";
    
    
/*    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("application/json");
        response.setHeader("Access-Control-Allow-Origin", "*");

        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT s.id, s.name, s.course_id, c.name AS course_name FROM students s JOIN courses c ON s.course_id = c.id")) {

            StringBuilder json = new StringBuilder("[");
            while (rs.next()) {
                json.append(String.format(
                    "{\"id\":%d,\"name\":\"%s\",\"course_id\":%d,\"course_name\":\"%s\"},",
                    rs.getInt("id"),
                    rs.getString("name").replace("\"", "\\\""),
                    rs.getInt("course_id"),
                    rs.getString("course_name").replace("\"", "\\\"")
                ));
            }
            if (json.charAt(json.length() - 1) == ',') json.deleteCharAt(json.length() - 1);
            json.append("]");
            response.getWriter().write(json.toString());

        } catch (SQLException e) {
            sendError(response, "Database error: " + e.getMessage());
        }
    }
to show course name in the tabele but not working 

   */ 
    
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("application/json");
        response.setHeader("Access-Control-Allow-Origin", "*");

        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT * FROM students")) {

            StringBuilder json = new StringBuilder("[");
            while (rs.next()) {
                json.append(String.format(
                    "{\"id\":%d,\"name\":\"%s\",\"course_id\":%d},",
                    rs.getInt("id"),
                    rs.getString("name").replace("\"", "\\\""),
                    rs.getInt("course_id")
                ));
            }
            if (json.charAt(json.length() - 1) == ',') json.deleteCharAt(json.length() - 1);
            json.append("]");
            response.getWriter().write(json.toString());

        } catch (SQLException e) {
            sendError(response, "Database error: " + e.getMessage());
        }
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("application/json");
        response.setHeader("Access-Control-Allow-Origin", "*");

        String action = request.getParameter("action");
        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD)) {
            switch (action) {
                case "add":
                    addStudent(conn, request, response);
                    break;
                case "update":
                    updateStudent(conn, request, response);
                    break;
                case "delete":
                    deleteStudent(conn, request, response);
                    break;
                default:
                    sendError(response, "Invalid action");
            }
        } catch (SQLException e) {
            sendError(response, "Database error: " + e.getMessage());
        }
    }

    private void addStudent(Connection conn, HttpServletRequest request, HttpServletResponse response)
            throws SQLException, IOException {
        String name = request.getParameter("name");
        int courseId = Integer.parseInt(request.getParameter("course_id"));
        String sql = "INSERT INTO students (name, course_id) VALUES (?, ?)";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, name);
            stmt.setInt(2, courseId);
            stmt.executeUpdate();
            response.getWriter().write("{\"status\":\"success\",\"message\":\"Student added\"}");
        }
    }

    private void updateStudent(Connection conn, HttpServletRequest request, HttpServletResponse response)
            throws SQLException, IOException {
        int id = Integer.parseInt(request.getParameter("id"));
        String name = request.getParameter("name");
        int courseId = Integer.parseInt(request.getParameter("course_id"));
        String sql = "UPDATE students SET name=?, course_id=? WHERE id=?";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, name);
            stmt.setInt(2, courseId);
            stmt.setInt(3, id);
            stmt.executeUpdate();
            response.getWriter().write("{\"status\":\"success\",\"message\":\"Student updated\"}");
        }
    }

    private void deleteStudent(Connection conn, HttpServletRequest request, HttpServletResponse response)
            throws SQLException, IOException {
        int id = Integer.parseInt(request.getParameter("id"));
        String sql = "DELETE FROM students WHERE id=?";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, id);
            stmt.executeUpdate();
            response.getWriter().write("{\"status\":\"success\",\"message\":\"Student deleted\"}");
        }
    }

    private void sendError(HttpServletResponse response, String message) throws IOException {
        response.setStatus(500);
        response.getWriter().write("{\"error\":\"" + message + "\"}");
    }
}
