package web;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/UserCourseServlet")
public class UserCourseServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    public UserCourseServlet() {
        super();
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType("application/json");
        PrintWriter out = response.getWriter();

        String courseId = request.getParameter("course_id");
        String courseName = request.getParameter("course_name");

        try {
            Class.forName("com.mysql.jdbc.Driver");
            Connection con = DriverManager.getConnection(
                    "jdbc:mysql://localhost:3306/yourdb", "root", "root");

            String query = "INSERT INTO classroom_c (course_id, course_name) VALUES (?, ?)";
            PreparedStatement ps = con.prepareStatement(query);
            ps.setInt(1, Integer.parseInt(courseId));
            ps.setString(2, courseName);

            int rows = ps.executeUpdate();

            if (rows > 0) {
                out.print("{\"status\":\"success\"}");
            } else {
                out.print("{\"status\":\"fail\"}");
            }

            con.close();
        } catch (Exception e) {
            e.printStackTrace();
            out.print("{\"status\":\"error\"}");
        }
    }
}
