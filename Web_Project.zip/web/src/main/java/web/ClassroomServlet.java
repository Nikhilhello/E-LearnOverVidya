package web;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONArray;
import org.json.JSONObject;

/**
 * Servlet implementation class ClassroomServlet
 */
@WebServlet("/ClassroomServlet")
public class ClassroomServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ClassroomServlet() {
        super();
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("application/json");
        PrintWriter out = response.getWriter();

        try {
            // Load JDBC driver
            Class.forName("com.mysql.jdbc.Driver");
            // Connect to database
            Connection con = DriverManager.getConnection(
                    "jdbc:mysql://localhost:3306/yourdb", "root", "root");

            // SQL query to fetch all classrooms
            String query = "SELECT * FROM classroom_c";
            PreparedStatement ps = con.prepareStatement(query);
            ResultSet rs = ps.executeQuery();

            // Convert ResultSet to JSON
            JSONArray classrooms = new JSONArray();

            while (rs.next()) {
                JSONObject obj = new JSONObject();
                obj.put("r_id", rs.getInt("r_id"));
                obj.put("course_id", rs.getInt("course_id"));
                obj.put("course_name", rs.getString("course_name"));
                classrooms.put(obj);
            }

            // Write JSON response
            out.print(classrooms.toString());
            con.close();
        } catch (Exception e) {
            e.printStackTrace();
            out.print("[]"); // Empty array on error
        }
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}
}
