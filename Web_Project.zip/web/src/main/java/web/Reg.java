package web; 
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse; 
/** 
* Servlet implementation class RegServlet 
*/ 
@WebServlet("/reg") 
public class Reg extends HttpServlet { 
private static final long serialVersionUID = 1L; 
/** 
* @see HttpServlet#HttpServlet() 
*/ 
public Reg() { 
super(); 
// TODO Auto-generated constructor stub 
} 
Connection con;
public void init(ServletConfig config)  
{  
try { 
Class.forName("com.mysql.cj.jdbc.Driver"); 
con=DriverManager.getConnection("jdbc:mysql://localhost:3306/yourdb", "root", "root"); 
} catch (ClassNotFoundException e) { 
// TODO Auto-generated catch block 
e.printStackTrace(); 
} catch (SQLException e) { 
// TODO Auto-generated catch block 
e.printStackTrace(); 
} 
} 
protected void doPost(HttpServletRequest request, 
HttpServletResponse response) throws ServletException, IOException { 
// TODO Auto-generated method stub 
	try { 
	    String s1 = request.getParameter("fname"); 
	    String s2 = request.getParameter("lname"); 
	    String s3 = request.getParameter("uname"); 
	    String s4 = request.getParameter("pword"); 
	    String s5 = request.getParameter("role");
	    
	    
	    // Debug logs
	    System.out.println("First Name: " + s1);
	    System.out.println("Last Name: " + s2);
	    System.out.println("Username: " + s3);
	    System.out.println("Role: " + s5);
	    System.out.println("Password: " + s4);


	    // Check if any field is empty
	    if (s1 == null || s1.isEmpty() ||
	        s2 == null || s2.isEmpty() ||
	        s3 == null || s3.isEmpty() ||
	  		s4 == null || s4.isEmpty() ||
	        s5 == null || s5.isEmpty() || s5.equals("Select Role")) {

	        // If any field is empty, show alert and redirect back to registration page
	        PrintWriter pw = response.getWriter(); 
	        pw.println("<script type='text/javascript'>"); 
	        pw.println("alert('All fields are mandatory for your Registration . Please fill all fields.');"); 
	        pw.println("location='index.html';");  // Redirect back to registration form
	        pw.println("</script>"); 
	    } else {
	        // All fields are filled, proceed with registration
	        PreparedStatement pstmt = con.prepareStatement("insert into web values(?,?,?,?,?)"); 
	        pstmt.setString(1, s1); 
	        pstmt.setString(2, s2); 
	        pstmt.setString(3, s3); 
	        pstmt.setString(4, s5); // role (4th column)
	        pstmt.setString(5, s4); // password (5th column)
	        pstmt.executeUpdate(); 
	        
	        // Redirect to home with success message
	        response.sendRedirect("index.html?msg=success"); 
	    }
} catch (SQLException e) { 
// TODO Auto-generated catch block 
e.printStackTrace(); 
} catch (IOException e) { 
// TODO Auto-generated catch block 
e.printStackTrace(); 
} 
} 
}